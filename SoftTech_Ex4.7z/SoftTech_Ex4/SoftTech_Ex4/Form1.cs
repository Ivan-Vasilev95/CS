﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftTech_Ex4
{
    public partial class Form1 : Form
    {
        int parPos;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Left = 0;
            this.Top = 0;
            generating_MenuStrip();
            generating_button();
            menuStrip1.BackColor = Color.White;
        }
        public void generating_MenuStrip()
        {
            ToolStripMenuItem fileToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.Items.Add(fileToolStripMenuItem);
            fileToolStripMenuItem.Text = "File";
            fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);

            ToolStripMenuItem newToolStripMenuItem = new ToolStripMenuItem();
            newToolStripMenuItem.Text = "New";
            fileToolStripMenuItem.DropDownItems.Add(newToolStripMenuItem);
            newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);

            ToolStripMenuItem editToolStripMenuItem = new ToolStripMenuItem();
            ToolStripMenuItem viewToolStripMenuItem = new ToolStripMenuItem();
            ToolStripMenuItem helpToolStripMenuItem = new ToolStripMenuItem();
            ToolStripMenuItem endToolStripMenuItem = new ToolStripMenuItem();
            endToolStripMenuItem.BackColor = Color.Red;


            menuStrip1.Items.Add(editToolStripMenuItem);
            menuStrip1.Items.Add(viewToolStripMenuItem);
            menuStrip1.Items.Add(helpToolStripMenuItem);
            menuStrip1.Items.Add(endToolStripMenuItem);
            

            editToolStripMenuItem.Text = "Edit";
            viewToolStripMenuItem.Text = "View";
            helpToolStripMenuItem.Text = "Help";
            endToolStripMenuItem.Text = "End";

            editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            endToolStripMenuItem.Click += new System.EventHandler(this.endToolStripMenuItem_Click);

            this.MainMenuStrip = MainMenuStrip;
            Controls.Add(MainMenuStrip);
        }

        public void generating_button()
        {
            Button btnDock = new Button();
            btnDock.Text = "Завърти менюто !";
            btnDock.Left = this.Width / 2;
            btnDock.Top = this.Height / 2;
            btnDock.Click += new System.EventHandler(this.btnDock_Click);
            Controls.Add(btnDock);
        }

        public void btnDock_Click(Object sender,System.EventArgs e)
        {
            switch (parPos)
            {
                case 0:
                    {
                        menuStrip1.Dock = DockStyle.Right;
                        break;
                    }
                case 1:
                    {
                        menuStrip1.Dock = DockStyle.Bottom;
                        break;
                    }
                case 2:
                    {
                        menuStrip1.Dock = DockStyle.Left;
                        break;
                    }
                case 3:
                    {
                        menuStrip1.Dock = DockStyle.Top;
                        break;
                    }
            }
        }
        private void fileToolStripMenuItem_Click(object sender , EventArgs e)
        {

        }
        private void newToolStripMenuItem_Click(object sender ,EventArgs e)
        {

        }
        private void editToolStripMenuItem_Click(object sender ,EventArgs e)
        {

        }
        private void viewToolStripMenuItem_Click(object sender , EventArgs e)
        {

        }
        private void helpToolStripMenuItem_Click(object sender ,EventArgs e)
        {

        }
        private void endToolStripMenuItem_Click (object sender ,EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            parPos = 0;

            if (parPos == 0)
            {
                parPos = 2;
            }
            else if(parPos==1)
            {
                parPos = 2;
            }
        }
    }
}
